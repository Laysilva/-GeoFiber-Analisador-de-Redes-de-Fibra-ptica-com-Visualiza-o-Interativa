# GeoFiber

Sistema de visualização e análise de incidentes em redes de fibra óptica.